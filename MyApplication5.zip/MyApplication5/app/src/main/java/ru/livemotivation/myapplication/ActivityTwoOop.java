package ru.livemotivation.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by User on 4/15/2017.
 */

public class ActivityTwoOop extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);

        ListView list_view_oop = findViewById(R.id.list_view_oop);
        list_view_oop.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0:
                      //  startActivity(new Intent(ActivityTwoOop.this, LessonsOneHelloWorldActivity.class));
                        Toast.makeText(ActivityTwoOop.this, "Классы и объекты", Toast.LENGTH_SHORT).show();
                        break;
                    case 1:
                        Toast.makeText(ActivityTwoOop.this, "Пакеты", Toast.LENGTH_SHORT).show();
                        break;
                    case 2:
                        Toast.makeText(ActivityTwoOop.this, "Модификаторы доступа и инкапсуляция", Toast.LENGTH_SHORT).show();
                        break;
                    case 3:
                        Toast.makeText(ActivityTwoOop.this, "Статический модификатор", Toast.LENGTH_SHORT).show();
                        break;
                    case 4:
                        Toast.makeText(ActivityTwoOop.this, "Объекты как параметры методов", Toast.LENGTH_SHORT).show();
                        break;
                    case 5:
                        Toast.makeText(ActivityTwoOop.this, "Внутренние и вложенные классы", Toast.LENGTH_SHORT).show();
                        break;
                    case 6:
                        Toast.makeText(ActivityTwoOop.this, "Наследование", Toast.LENGTH_SHORT).show();
                        break;
                    case 7:
                        Toast.makeText(ActivityTwoOop.this, "Абстрактные классы", Toast.LENGTH_SHORT).show();
                        break;
                    case 8:
                        Toast.makeText(ActivityTwoOop.this, "Иерархия наследования", Toast.LENGTH_SHORT).show();
                        break;
                    case 9:
                        Toast.makeText(ActivityTwoOop.this, "Интерфейсы", Toast.LENGTH_SHORT).show();
                        break;
                    case 10:
                        Toast.makeText(ActivityTwoOop.this, "Интерфейсы в механизме обратного вызова", Toast.LENGTH_SHORT).show();
                        break;
                    case 11:
                        Toast.makeText(ActivityTwoOop.this, "Перечисления enum", Toast.LENGTH_SHORT).show();
                        break;
                    case 12:
                        Toast.makeText(ActivityTwoOop.this, "Класс Object и его методы", Toast.LENGTH_SHORT).show();
                        break;
                    case 13:
                        Toast.makeText(ActivityTwoOop.this, "Обобщения (Generics)", Toast.LENGTH_SHORT).show();
                        break;
                    case 14:
                        Toast.makeText(ActivityTwoOop.this, "Ограничения обобщений", Toast.LENGTH_SHORT).show();
                        break;
                    case 15:
                        Toast.makeText(ActivityTwoOop.this, "Наследование и обобщения", Toast.LENGTH_SHORT).show();
                        break;
                    case 16:
                        Toast.makeText(ActivityTwoOop.this, "Ссылочные типы и копирование объектов", Toast.LENGTH_SHORT).show();
                        break;
                    case 17:
                        Toast.makeText(ActivityTwoOop.this, "Обработка исключений", Toast.LENGTH_SHORT).show();
                        break;
                    case 18:
                        Toast.makeText(ActivityTwoOop.this, "Классы исключений", Toast.LENGTH_SHORT).show();
                        break;
                    case 19:
                        Toast.makeText(ActivityTwoOop.this, "Создание своих классов исключений", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
       // TextView title = (TextView) findViewById(R.id.activityTitle2);
       // title.setText("This is ActivityTwoOop");

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavView_Bar);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.ic_main:
                        Intent intent0 = new Intent(ActivityTwoOop.this, MainActivity.class);
                        startActivity(intent0);
                        break;

                    case R.id.ic_basics:
                        Intent intent1 = new Intent(ActivityTwoOop.this, ActivityOneLessonsTheme.class);
                        startActivity(intent1);
                        break;

                    case R.id.ic_oop:

                        break;

                    case R.id.ic_collections:
                        Intent intent3 = new Intent(ActivityTwoOop.this, ActivityThreeCollections.class);
                        startActivity(intent3);
                        break;

                    case R.id.ic_other:
                        Intent intent4 = new Intent(ActivityTwoOop.this, ActivityFourOther.class);
                        startActivity(intent4);
                        break;
                }


                return false;
            }
        });
    }

}
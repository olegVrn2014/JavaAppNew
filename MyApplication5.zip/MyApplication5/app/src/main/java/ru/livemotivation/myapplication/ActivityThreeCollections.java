package ru.livemotivation.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;



public class ActivityThreeCollections extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_three);

        ListView list_view_collectiobs = findViewById(R.id.list_view_collections);
        list_view_collectiobs.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0:
                        //  startActivity(new Intent(ActivityTwoOop.this, LessonsOneHelloWorldActivity.class));
                        Toast.makeText(ActivityThreeCollections.this, "Типы коллекций. Интерфейс Collection", Toast.LENGTH_SHORT).show();
                        break;
                    case 1:
                        Toast.makeText(ActivityThreeCollections.this, "Класс ArrayList и интерфейс List", Toast.LENGTH_SHORT).show();
                        break;
                    case 2:
                        Toast.makeText(ActivityThreeCollections.this, "Очереди и класс ArrayDeque", Toast.LENGTH_SHORT).show();
                        break;
                    case 3:
                        Toast.makeText(ActivityThreeCollections.this, "Класс LinkedList", Toast.LENGTH_SHORT).show();
                        break;
                    case 4:
                        Toast.makeText(ActivityThreeCollections.this, "Интерфейс Set и класс HashSet", Toast.LENGTH_SHORT).show();
                        break;
                    case 5:
                        Toast.makeText(ActivityThreeCollections.this, "SortedSet, NavigableSet, TreeSet", Toast.LENGTH_SHORT).show();
                        break;
                    case 6:
                        Toast.makeText(ActivityThreeCollections.this, "Интерфейсы Comparable и Comparator", Toast.LENGTH_SHORT).show();
                        break;
                    case 7:
                        Toast.makeText(ActivityThreeCollections.this, "Интерфейс Map и класс HashMap", Toast.LENGTH_SHORT).show();
                        break;
                    case 8:
                        Toast.makeText(ActivityThreeCollections.this, "Интерфейсы SortedMap и NavigableMap", Toast.LENGTH_SHORT).show();
                        break;
                    case 9:
                        Toast.makeText(ActivityThreeCollections.this, "Итераторы", Toast.LENGTH_SHORT).show();
                        break;

                }
            }
        });
        // TextView title = (TextView) findViewById(R.id.activityTitle3);
        // title.setText("This is ActivityThreeCollections");

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavView_Bar);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(3);
        menuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.ic_main:
                        Intent intent0 = new Intent(ActivityThreeCollections.this, MainActivity.class);
                        startActivity(intent0);
                        break;

                    case R.id.ic_basics:
                        Intent intent1 = new Intent(ActivityThreeCollections.this, ActivityOneLessonsTheme.class);
                        startActivity(intent1);
                        break;

                    case R.id.ic_oop:
                        Intent intent2 = new Intent(ActivityThreeCollections.this, ActivityTwoOop.class);
                        startActivity(intent2);
                        break;

                    case R.id.ic_collections:

                        break;

                    case R.id.ic_other:
                        Intent intent4 = new Intent(ActivityThreeCollections.this, ActivityFourOther.class);
                        startActivity(intent4);
                        break;
                }


                return false;
            }
        });
    }
}


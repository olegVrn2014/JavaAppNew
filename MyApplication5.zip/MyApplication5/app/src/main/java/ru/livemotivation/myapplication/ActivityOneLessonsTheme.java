package ru.livemotivation.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import ru.livemotivation.myapplication.lessons_java.LessonsOneHelloWorldActivity;
import ru.livemotivation.myapplication.lessons_java.LessonsThreeTypeActivity;
import ru.livemotivation.myapplication.lessons_java.LessonsTwoVariablesActivity;

public class ActivityOneLessonsTheme extends AppCompatActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one);
        ListView list_view_theme = findViewById(R.id.list_view_theme);
        list_view_theme.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               switch (position){
                   case 0:
                       startActivity(new Intent(ActivityOneLessonsTheme.this, LessonsOneHelloWorldActivity.class));
                       Toast.makeText(ActivityOneLessonsTheme.this, "Первая программа", Toast.LENGTH_SHORT).show();
                       break;
                   case 1:
                       startActivity(new Intent(ActivityOneLessonsTheme.this, LessonsTwoVariablesActivity.class));
                       Toast.makeText(ActivityOneLessonsTheme.this, "Переменные", Toast.LENGTH_SHORT).show();
                       break;
                   case 2:
                       startActivity(new Intent(ActivityOneLessonsTheme.this, LessonsThreeTypeActivity.class));
                       Toast.makeText(ActivityOneLessonsTheme.this, "Типы данных", Toast.LENGTH_SHORT).show();
                       break;
                   case 3:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Консольный ввод", Toast.LENGTH_SHORT).show();
                       break;
                   case 4:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Арифметические операции", Toast.LENGTH_SHORT).show();
                       break;
                   case 5:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Поразрядные операции", Toast.LENGTH_SHORT).show();
                       break;
                   case 6:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Условные выражения", Toast.LENGTH_SHORT).show();
                       break;
                   case 7:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Операции присваивания", Toast.LENGTH_SHORT).show();
                       break;
                   case 8:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Преобразование базовых типов данных", Toast.LENGTH_SHORT).show();
                       break;
                   case 9:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Условные конструкции", Toast.LENGTH_SHORT).show();
                       break;
                   case 10:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Циклы", Toast.LENGTH_SHORT).show();
                       break;
                   case 11:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Массивы", Toast.LENGTH_SHORT).show();
                       break;
                   case 12:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Методы", Toast.LENGTH_SHORT).show();
                       break;
                   case 13:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Параметры методов", Toast.LENGTH_SHORT).show();
                       break;
                   case 14:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Оператор return", Toast.LENGTH_SHORT).show();
                       break;
                   case 15:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Перегрузка методов", Toast.LENGTH_SHORT).show();
                       break;
                   case 16:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Рекурсивные функции", Toast.LENGTH_SHORT).show();
                       break;
                   case 17:
                       Toast.makeText(ActivityOneLessonsTheme.this, "Обработка исключений", Toast.LENGTH_SHORT).show();
                       break;
               }
            }
        });

      // TextView title = (TextView) findViewById(R.id.activityTitle1);
       //title.setText("Изучение JAVA");

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavView_Bar);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.ic_main:
                        Intent intent0 = new Intent(ActivityOneLessonsTheme.this, MainActivity.class);
                        startActivity(intent0);
                        break;

                    case R.id.ic_basics:

                        break;

                    case R.id.ic_oop:
                        Intent intent2 = new Intent(ActivityOneLessonsTheme.this, ActivityTwoOop.class);
                        startActivity(intent2);
                        break;

                    case R.id.ic_collections:
                        Intent intent3 = new Intent(ActivityOneLessonsTheme.this, ActivityThreeCollections.class);
                        startActivity(intent3);
                        break;

                    case R.id.ic_other:
                        Intent intent4 = new Intent(ActivityOneLessonsTheme.this, ActivityFourOther.class);
                        startActivity(intent4);
                        break;
                }


                return false;
            }
        });
    }
}